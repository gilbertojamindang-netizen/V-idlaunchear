# VøidLaunch

Minecraft Java launcher for Android.

## Setup

1. Open project in **Android Studio**
2. Let Gradle sync finish
3. For Microsoft login — replace `YOUR_AZURE_CLIENT_ID` in `MicrosoftAuthActivity.java` with your Azure app client ID
4. Build → Generate Signed APK or upload to GitHub Actions

## GitHub Actions (Auto-build APK)

Create `.github/workflows/build.yml` in your repo:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with:
          java-version: '11'
          distribution: 'temurin'
      - name: Build APK
        run: ./gradlew assembleRelease
      - name: Upload APK
        uses: actions/upload-artifact@v3
        with:
          name: VoidLaunch.apk
          path: app/build/outputs/apk/release/*.apk
```

Push to GitHub → Actions tab → download APK automatically.

## Features
- Microsoft Account login
- Offline mode (custom username)
- Version selector (1.7.10 → 1.21.4)
- RAM allocation slider
- Dark void purple theme

## TODO (next steps)
- Integrate PojavLauncher engine for actual game launching
- Add mod support
- Add skin viewer
