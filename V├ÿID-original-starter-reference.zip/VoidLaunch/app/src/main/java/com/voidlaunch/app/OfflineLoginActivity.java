package com.voidlaunch.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class OfflineLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline_login);

        EditText etUsername = findViewById(R.id.et_username);
        Button btnPlay = findViewById(R.id.btn_play);

        btnPlay.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            if (TextUtils.isEmpty(username) || username.length() < 3) {
                Toast.makeText(this, "Username must be at least 3 characters", Toast.LENGTH_SHORT).show();
                return;
            }
            SharedPreferences prefs = getSharedPreferences("voidlaunch", MODE_PRIVATE);
            prefs.edit()
                .putString("username", username)
                .putString("account_type", "offline")
                .apply();

            Intent intent = new Intent(this, LauncherActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
