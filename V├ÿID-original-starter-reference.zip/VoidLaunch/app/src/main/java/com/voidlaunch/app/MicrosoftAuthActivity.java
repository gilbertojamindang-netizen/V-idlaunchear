package com.voidlaunch.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MicrosoftAuthActivity extends AppCompatActivity {

    private static final String CLIENT_ID = "YOUR_AZURE_CLIENT_ID"; // Replace with your Azure App Client ID
    private static final String REDIRECT_URI = "https://login.microsoftonline.com/common/oauth2/nativeclient";
    private static final String AUTH_URL =
        "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize" +
        "?client_id=" + CLIENT_ID +
        "&response_type=code" +
        "&redirect_uri=" + Uri.encode(REDIRECT_URI) +
        "&scope=" + Uri.encode("XboxLive.signin offline_access");

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_microsoft_auth);

        WebView webView = findViewById(R.id.webview_auth);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (url.startsWith(REDIRECT_URI)) {
                    Uri uri = Uri.parse(url);
                    String code = uri.getQueryParameter("code");
                    if (code != null) {
                        handleAuthCode(code);
                    }
                }
            }
        });
        webView.loadUrl(AUTH_URL);
    }

    private void handleAuthCode(String code) {
        // TODO: Exchange code for token via your backend or directly
        SharedPreferences prefs = getSharedPreferences("voidlaunch", MODE_PRIVATE);
        prefs.edit()
            .putString("ms_auth_code", code)
            .putString("account_type", "microsoft")
            .apply();

        Intent intent = new Intent(this, LauncherActivity.class);
        startActivity(intent);
        finish();
    }
}
