package com.voidlaunch.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnMicrosoft = findViewById(R.id.btn_microsoft);
        Button btnOffline = findViewById(R.id.btn_offline);

        btnMicrosoft.setOnClickListener(v -> {
            Intent intent = new Intent(this, MicrosoftAuthActivity.class);
            startActivity(intent);
        });

        btnOffline.setOnClickListener(v -> {
            Intent intent = new Intent(this, OfflineLoginActivity.class);
            startActivity(intent);
        });
    }
}
