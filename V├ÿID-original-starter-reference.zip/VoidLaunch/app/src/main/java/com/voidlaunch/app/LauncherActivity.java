package com.voidlaunch.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LauncherActivity extends AppCompatActivity {

    private static final String[] VERSIONS = {
        "1.21.4", "1.21.3", "1.21.1", "1.20.4", "1.20.1",
        "1.19.4", "1.19.2", "1.18.2", "1.17.1", "1.16.5",
        "1.12.2", "1.8.9", "1.7.10"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        SharedPreferences prefs = getSharedPreferences("voidlaunch", MODE_PRIVATE);
        String username = prefs.getString("username", "Player");
        String accountType = prefs.getString("account_type", "offline");

        TextView tvUser = findViewById(R.id.tv_username);
        tvUser.setText(username + (accountType.equals("offline") ? " (Offline)" : " (Microsoft)"));

        Spinner versionSpinner = findViewById(R.id.spinner_version);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, VERSIONS);
        versionSpinner.setAdapter(adapter);

        SeekBar ramBar = findViewById(R.id.seekbar_ram);
        TextView tvRam = findViewById(R.id.tv_ram);
        ramBar.setMax(7); // 1GB to 8GB
        ramBar.setProgress(1); // default 2GB
        tvRam.setText("RAM: 2 GB");
        ramBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int ram = progress + 1;
                tvRam.setText("RAM: " + ram + " GB");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });

        Button btnLaunch = findViewById(R.id.btn_launch);
        btnLaunch.setOnClickListener(v -> {
            String selectedVersion = versionSpinner.getSelectedItem().toString();
            int ram = ramBar.getProgress() + 1;
            Toast.makeText(this,
                "Launching " + selectedVersion + " with " + ram + "GB RAM...",
                Toast.LENGTH_SHORT).show();
            // TODO: Integrate with PojavLauncher engine to actually launch
        });

        Button btnLogout = findViewById(R.id.btn_logout);
        btnLogout.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            finish();
        });
    }
}
