# Source map and working rules

- `VØID-Launcher/` — untouched copy of the user's original small Android Java starter project.
- `SOURCE-LICENSES/` — license texts copied from the two uploaded upstream source archives for review.
- `INTEGRATION_AUDIT.md` — findings, compatibility decision, and next steps.

Original uploaded archives are not included in this package because they remain the authoritative pristine copies. Keep `horizon-android-android.zip` and `ZalithLauncher2-main.zip` unchanged as backups.

Do not treat Horizon's 26.3 Rust client as a drop-in engine for Minecraft 1.21.11. Do not remove copyright/license files from either upstream project. Do not commit Minecraft game assets, account tokens, or signing keys.
