# VØID LAUNCHER — Integration Phase 1 Audit

Date: 2026-11-05
Status: Source audit and architecture decision only. No engine has been merged and no playable APK has been built.

## Uploaded inputs inspected

- `VoidLaunch.zip` — small Android Java starter (42 ZIP entries). It contains Activities/layouts and basic dependencies, but its README explicitly lists Pojav engine integration as a TODO. It is not currently a functional Minecraft launcher.
- `ZalithLauncher2-main.zip` — 2,249 ZIP entries; archive integrity check passed. It is a substantial Android/Kotlin/Jetpack Compose launcher project with launcher/game infrastructure and Pojav-derived Android LWJGL/native integration.
- `horizon-android-android.zip` — 5,288 ZIP entries; archive integrity check passed. It is an Android port of a native Rust client targeting Minecraft Java 26.3, not a drop-in renderer or engine for Minecraft 1.21.11.

## Decision for the requested Minecraft 1.21.11 target

1. Use Zalith Launcher 2 as the technical foundation for Java Edition 1.21.11. Its version-selection/download infrastructure and Pojav-based runtime path are the relevant route for running Java JAR versions on Android. We still need to verify 1.21.11 end-to-end by downloading its official version metadata, resolving libraries/assets, and launching on a real Android device.
2. Do not merge Horizon's game engine into this 1.21.11 build. The uploaded Horizon Android README explicitly says the engine targets Minecraft Java 26.3. Its game implementation is a separate native Rust client, not a generic Vulkan renderer that can simply replace Zalith's rendering backend.
3. Keep Horizon as a separately reviewed research/reference source. Only consider isolated, independently compatible components after code-level review. Do not copy Horizon game logic into the Zalith Java runtime path.
4. Treat the current VØID Java starter as a design/branding reference. Replacing Zalith's launcher UI with VØID branding is more practical than embedding all of Zalith into the tiny starter project.

## What was verified in the source

- Horizon README: describes a native Android port of the Rust Horizon engine for Minecraft Java 26.3; Android 9+, Vulkan; `.hmod` mods; explicitly says Fabric/Forge Java code does not run in that client.
- Zalith source: Android/Kotlin project; includes LWJGL modules and Android native bridge code. Its game UI includes a 1.21.11 sample/version string, but that alone is not proof that a full 1.21.11 launch has been tested.
- VØID README: lists engine integration as a TODO. Current VØID project is not yet connected to a game-launching engine.

## Integration plan

### Phase 1 — completed
- Inspect ZIP integrity and top-level project structure.
- Identify the actual role and target version of Horizon.
- Select Zalith as the Java 1.21.11 foundation; keep Horizon separate for now.
- Preserve original upstream license texts in `SOURCE-LICENSES/`.

### Phase 2 — next
- Prepare a clean VØID-branded fork/working copy of Zalith (do not overwrite the original archive).
- Inspect Gradle wrapper, Android Gradle Plugin, Kotlin, NDK, ABI filters, native libraries, and build flavors.
- Trace version manifest -> download -> library/native extraction -> Java command line -> game surface lifecycle.
- Confirm official Minecraft 1.21.11 metadata and required Java runtime from the version manifest.
- Build debug APK and test launch on a real Android device.

### Phase 3 — features
- Apply VØID UI branding and navigation.
- Preserve Zalith's functional game launch path.
- Add VØID-specific home screen, version selector, account/profile display, RAM controls, worlds/mods/packs entry points only where backed by real implementations.
- Test offline singleplayer after required game files and authentication/session setup have been completed. Online multiplayer still needs network access and valid authentication where required.

## License and distribution cautions

- Horizon source includes an MIT license. Retain its copyright and license notice for any portions reused.
- Zalith source includes GPL-3.0. A distributed modified build based on it must comply with GPL-3.0, including providing corresponding source under the required terms and preserving notices. Review the repository's own branding/attribution requirements before publishing; do not remove upstream credits.
- Both projects contain third-party components with their own notices/licenses. Preserve and review those notices before redistribution.
- Minecraft is proprietary software. Do not bundle Mojang game JARs/assets or Microsoft credentials in the repository or APK. Let users obtain game files through legitimate account-based flows.

## Build status

Not built or tested in this environment. No APK is claimed. This package is an audit/working starter, not a playable release.
