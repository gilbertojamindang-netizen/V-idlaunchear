# Engine source location

The Horizon Android engine is intentionally not copied into this ZIP. Review and pin the upstream source before adding it here:

- Repository: https://github.com/Vasysik/horizon-android
- Branch currently documented for Android: `android`

After review, add the source as a Git submodule or a pinned vendored directory and preserve its LICENSE and THIRD_PARTY_NOTICES. Do not place Minecraft assets, generated game resources, account tokens, APK signing keys, or private credentials in this folder or Git history.

The current VØID Java shell does not yet call into this engine. See `docs/ENGINE_ADOPTION.md`.
