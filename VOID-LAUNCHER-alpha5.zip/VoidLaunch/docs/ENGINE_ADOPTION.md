# VØID engine adoption plan — Alpha 0.5

## Decision

Use the Android port of Horizon as the game implementation, then rebrand/adapt its Android launcher shell as VØID after reviewing the upstream license and notices. Do **not** treat Horizon as a Java dependency or attempt to launch its Rust engine from the current Java shell without its documented Android integration.

Selected source for evaluation: https://github.com/Vasysik/horizon-android (Android branch).

## Verified engine characteristics

The upstream Android documentation describes:

- Native Rust / wgpu game client for Minecraft Java 26.3.
- ARM64 Android target and Vulkan rendering.
- Singleplayer and Java multiplayer.
- An initial on-device download of roughly 500 MiB of required resources; verified resources are reused after installation, allowing later offline launches.
- No separate Java runtime required on the phone for gameplay.
- Native `.hmod` mod packages and resource packs; Fabric/Forge/NeoForge Java mod JARs do not run in this engine.
- App-private storage for worlds, profiles, caches and account data.

These are upstream project claims, not tests performed on this VØID project. Confirm current requirements against the selected upstream commit before building.

## Integration sequence

1. Review the upstream repository's `LICENSE`, `THIRD_PARTY_NOTICES.md`, `docs/android.md`, and publication notes.
2. Pin a specific reviewed commit; do not build production releases from a moving branch.
3. Build and install the upstream Android app unchanged on a physical ARM64/Vulkan device first. Record the APK version, commit, Android version, device ABI and GPU/Vulkan details.
4. Confirm first-run resource preparation, singleplayer world creation, save/reopen, force-stop/relaunch offline, touch controls, and a supported `.hmod` / resource pack.
5. Choose one integration shape: (a) maintain a VØID-branded fork of the Horizon Android app (preferred if the upstream structure is already the complete launcher+engine), or (b) use a documented exported Android entry point/library if upstream explicitly provides one. Do not invent an Activity class, package name, JNI symbol, or Gradle module.
6. Move VØID branding and only compatible launcher features into the fork. Preserve engine lifecycle, storage, update, license, and security behavior.
7. Rebuild and run the same physical-device tests. Only then replace the pending Play / Create / Join actions in this Java prototype.

## Why the current app cannot yet launch the game

The current `app` module is a Java UI shell. It contains no Rust engine source, compiled `.so` libraries, native activity, game resources, or supported engine API. Its file pickers only retain Android document URIs. Therefore the current `Play`, `Instant Join`, and `Create World` controls correctly remain pending.

## Offline gameplay behavior

Offline play is possible only after the engine and the required Minecraft resources have been legitimately installed and verified. The VØID offline username/profile screen is not an entitlement check and does not download or create game files. Do not describe the current alpha as playable offline.

## Compatibility boundaries

| Requested feature | Horizon route |
|---|---|
| Offline singleplayer after resource setup | Supported by upstream docs |
| Create/load/save worlds | Engine-owned; validate on device |
| Vulkan | Primary Android renderer; test device driver |
| OpenGL ES fallback | Do not promise unless selected engine revision documents it |
| Instant Join | Needs engine multiplayer flow; verify exact API/UI |
| Native `.hmod` mods | Supported format; installer integration required |
| Fabric/Forge/NeoForge `.jar` mods | Not supported |
| Java Runtime Manager | Not needed for Horizon gameplay |
| Microsoft sign-in | Current Android port docs describe development configuration; production registration/approval must be resolved |

## Release gate

Do not label VØID playable or publish a release APK until the engine is actually included, the app builds, and offline world create/save/reopen has passed on a physical supported phone.
