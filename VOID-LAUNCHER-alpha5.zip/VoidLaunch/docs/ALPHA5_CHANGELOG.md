# Alpha 0.5.0 changes

- Bumped Android app version to 0.5.0-alpha.
- Made the Horizon adoption decision explicit: use the native Android port as a fork/adopted engine, not a pretend Java library.
- Added a source review, commit pinning, integration sequence and physical-device release gate.
- Documented the actual offline requirement: initial game-resource preparation must finish before later offline launches.
- Clarified feature incompatibilities: no Java `.jar` mods and no separate Java runtime manager on the Horizon path.
- Updated the Play/Join/Create pending dialog to point to the new integration plan.
- No engine binaries were added; this is still a non-playable launcher shell.
