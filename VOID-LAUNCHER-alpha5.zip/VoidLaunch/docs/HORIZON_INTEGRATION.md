# Horizon engine integration — engineering status

## Important architecture decision

The original ZIP was a small Java/Android UI shell. It did not contain a Minecraft runtime, renderer, game assets, account flow, or a Horizon engine. A launcher screen cannot become a working Minecraft launcher merely by adding buttons.

The Horizon Android project discovered for this plan is a **native Rust game engine**, not a Java Minecraft launcher. Its Android documentation describes Vulkan rendering, a bundled/native runtime path, and a specific Minecraft version target. That means the requested Java Runtime Manager and arbitrary legacy Java-version selector do not apply to this engine. Java Fabric/Forge/NeoForge JAR mods are not automatically compatible with Horizon; the Android port documents native `.hmod` mods and resource/data packs instead. Do not label `.jar` files as supported Horizon mods.

## Current VØID status

- Android shell, offline profile, saved performance preference: implemented in this repository.
- Mod/add-on file picker: implemented as a URI import list only. It does not install or execute a mod.
- Instant Join, Create World, Play: clearly marked pending; no fake launch action is performed.
- Microsoft sign-in: intentionally disabled. The old sample stored an OAuth authorization code as if it were a signed-in account, which was not secure or functional.
- Horizon engine, Vulkan renderer, world storage, multiplayer, real mod loading: not included yet.

## Recommended integration target

Review the upstream Android port and its license/third-party notices before vendoring or linking it:

- https://github.com/Vasysik/horizon-android
- Android build and architecture notes: https://github.com/Vasysik/horizon-android/blob/android/docs/android.md

Treat that project as a separately maintained engine component. Pin a reviewed commit, preserve its license and notices, and build/test the engine APK or native libraries for `arm64-v8a`. Do not copy game assets, proprietary Minecraft files, account tokens, or signing keys into this repository.

## Work required before calling VØID playable

1. Choose the exact Horizon Android upstream/fork and pin a commit.
2. Confirm its supported Android API, NDK, Rust toolchain, ABI, renderer and mod formats.
3. Integrate its native Android entry point and lifecycle with this app, or make VØID a branded distribution of the engine if its license and maintainers permit that architecture.
4. Replace the pending Play/Join/Create actions with calls to the engine's actual documented interfaces.
5. Implement world/server selection using engine APIs and test save compatibility.
6. Implement `.hmod`/resource-pack import using the engine's verifier and installer; reject unsupported Java mod JARs.
7. Complete Microsoft device-code/OAuth sign-in using a project-owned app registration, PKCE/state validation as required, secure token storage, Xbox Live and Minecraft entitlement/profile exchange. Never persist an authorization code as a token.
8. Test on physical ARM64 devices with Vulkan; provide a clear unsupported-device message. Add GLES/OpenGL fallback only if the chosen engine actually supports it.
9. Run CI builds and real-device tests before publishing a release APK.

## Feature compatibility note

Horizon is not the same thing as PojavLauncher. If the product requirement is broad Java Edition compatibility (many versions, Java runtimes, Fabric/Forge/NeoForge), choose a Java launcher engine such as a Pojav-based architecture instead of assuming Horizon can provide those features. Avoid mixing incompatible engine assumptions in the same UI.
