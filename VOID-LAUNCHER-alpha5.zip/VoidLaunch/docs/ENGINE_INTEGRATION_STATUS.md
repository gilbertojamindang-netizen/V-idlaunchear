# VØID engine integration — Alpha 3

## What this alpha adds

- A device preflight screen checks Android 10+, `arm64-v8a`, and whether Android reports the Vulkan hardware feature/version.
- The check is diagnostic only. Passing it does **not** prove that a particular GPU driver can run Horizon, and it does not launch Minecraft.
- The launcher continues to show Play / Join / Create World as pending until the engine is actually integrated.

## Selected engine target

The reviewed Horizon Android project is a native Rust game for Minecraft Java Edition 26.3. Its documented Android baseline is ARM64 and Vulkan. It is not a general-purpose Java launcher: it does not run arbitrary Minecraft versions or Fabric/Forge/NeoForge Java `.jar` mods. Its own native `.hmod` format and resource/data packs are the relevant extension paths. A Java Runtime Manager and OpenGL fallback must not be advertised as supported unless a selected engine implementation documents them.

## Integration route

The current upstream Android app is a complete app/launcher rather than a published stable Android SDK. The realistic route is to review its license, notices, Android lifecycle, account flow and build setup, then decide whether VØID should become a branded distribution/fork or whether the upstream engine can be separated into a reusable library. Do not invent JNI entry points or copy undocumented internals into this Java shell.

Before any merge: pin an exact upstream commit; preserve all notices; build for `arm64-v8a`; verify Vulkan on physical devices; confirm game-resource download and entitlement flow; test singleplayer saves, multiplayer, offline-after-install, `.hmod` imports and resource packs. Never bundle Minecraft assets, game files, credentials, access tokens or signing keys.

## References reviewed

- Horizon Android project: https://github.com/Vasysik/horizon-android
- Android build and behavior notes: https://github.com/Vasysik/horizon-android/blob/android/docs/android.md

The upstream repository and its current branch may change. Re-check the exact revision and licenses before integrating.
