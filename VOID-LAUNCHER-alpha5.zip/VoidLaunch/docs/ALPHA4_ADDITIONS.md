# VØID LAUNCHER — Alpha 4 additions

## Added in this revision

- Resource pack ZIP picker using Android Storage Access Framework. The selected document URI is retained with read permission where the provider supports persistable grants.
- Worlds-folder picker using `OpenDocumentTree`; read/write access is requested only for the folder the user selects.
- Runtime package picker to record a user-selected package for later engine-adapter research. It does not install or execute a runtime.
- Status labels show which references have been selected.

## Still not implemented

- Horizon engine binaries or JNI/native bridge.
- Minecraft game download, entitlement verification, or actual game launch.
- Offline singleplayer, world creation/loading, multiplayer/Instant Join.
- Applying resource packs or loading `.hmod` add-ons.
- Java runtime installation/management.
- Microsoft/Xbox authentication.
- Vulkan/OpenGL rendering backend. The device check is diagnostic only.

## Permissions and data handling

The app uses Android's system document pickers rather than broad storage permissions. Persisted URI grants are limited to the documents/folder the user selects. No camera, microphone, or all-files access is requested.
