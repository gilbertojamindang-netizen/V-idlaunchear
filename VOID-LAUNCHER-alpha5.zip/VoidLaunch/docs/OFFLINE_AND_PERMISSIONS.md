# Offline mode and Android permissions

## Offline profile

The launcher stores an offline/online profile preference locally. This is a UI/profile setting only. It does not authenticate a Microsoft account, create an offline game session, or launch Minecraft. Real offline single-player requires a bundled/integrated game engine plus game assets and libraries already present on the device. Multiplayer and account-backed services require network access and valid authentication.

## Permissions

- `INTERNET` and `ACCESS_NETWORK_STATE` are normal manifest permissions; Android does not show a runtime approval dialog for them.
- `POST_NOTIFICATIONS` is requested only on Android 13+ and only from the Permission Manager screen. It is optional.
- Mods, resource packs, and world files should be selected through Android's Storage Access Framework. The app should not request broad all-files access.
- Camera and microphone permissions are intentionally absent until a concrete feature requires them.

## Current limitations

The engine is not included. The Play, Instant Join, and Create World controls remain disabled/pending. The import picker records references to selected files; it does not install, validate, or execute mods. Do not treat the current offline toggle as playable offline mode.
