# VØID Launcher currently has minification disabled. Add keep rules when
# a real game engine, authentication SDK, or reflection-based library is integrated.
