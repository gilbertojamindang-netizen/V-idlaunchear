package com.voidlaunch.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class OfflineLoginActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offline_login);
        EditText usernameField = findViewById(R.id.et_username);
        Button play = findViewById(R.id.btn_play);
        play.setOnClickListener(v -> {
            String username = usernameField.getText().toString().trim();
            if (!username.matches("[A-Za-z0-9_]{3,16}")) {
                Toast.makeText(this, "Use 3–16 letters, numbers or underscores.", Toast.LENGTH_LONG).show();
                return;
            }
            SharedPreferences prefs = getSharedPreferences("voidlaunch", MODE_PRIVATE);
            prefs.edit().putString("username", username).putString("account_type", "offline").apply();
            startActivity(new Intent(this, LauncherActivity.class));
            finish();
        });
    }
}
