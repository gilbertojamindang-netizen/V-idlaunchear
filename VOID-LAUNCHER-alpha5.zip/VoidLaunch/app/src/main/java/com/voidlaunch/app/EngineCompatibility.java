package com.voidlaunch.app;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.FeatureInfo;
import android.os.Build;
import java.util.Arrays;
import java.util.Locale;

/** Preflight checks for the selected Horizon Android engine target. This does not load the engine. */
public final class EngineCompatibility {
    private EngineCompatibility() {}

    public static String report(Context context) {
        PackageManager pm = context.getPackageManager();
        boolean arm64 = Arrays.asList(Build.SUPPORTED_ABIS).contains("arm64-v8a");
        boolean androidVersion = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q;
        boolean vulkanFeature = pm.hasSystemFeature(PackageManager.FEATURE_VULKAN_HARDWARE_LEVEL);
        String vulkanVersion = "not reported";
        for (FeatureInfo feature : pm.getSystemAvailableFeatures()) {
            if (feature != null && "android.hardware.vulkan.version".equals(feature.name)) {
                int v = feature.version;
                int major = (v >> 22) & 0x3ff;
                int minor = (v >> 12) & 0x3ff;
                int patch = v & 0xfff;
                vulkanVersion = String.format(Locale.US, "%d.%d.%d", major, minor, patch);
                break;
            }
        }
        boolean ready = arm64 && androidVersion && vulkanFeature;
        return "DEVICE PREFLIGHT\n\n" +
                "Android: " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") · " + (androidVersion ? "PASS" : "NEEDS ANDROID 10+") + "\n" +
                "CPU ABI: " + Build.SUPPORTED_ABIS[0] + " · " + (arm64 ? "ARM64 PASS" : "ARM64 REQUIRED") + "\n" +
                "Vulkan hardware feature: " + (vulkanFeature ? "reported" : "not reported") + "\n" +
                "Vulkan version: " + vulkanVersion + "\n\n" +
                (ready ? "Basic Horizon target checks passed. Actual GPU driver compatibility still requires a real engine launch test."
                       : "This device does not meet one or more documented Horizon Android baseline requirements.") +
                "\n\nThis is only a compatibility preflight. Horizon engine binaries are not bundled in this alpha.";
    }
}
