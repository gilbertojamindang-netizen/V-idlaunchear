package com.voidlaunch.app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import java.util.ArrayList;
import java.util.List;

/** UI/profile layer. Actual gameplay requires the separately licensed Horizon Android engine. */
public class LauncherActivity extends AppCompatActivity {
    private static final String[] QUALITY = {"Low — 4 chunks", "Balanced — 6 chunks", "High — 8 chunks"};
    private ActivityResultLauncher<String[]> modPicker;
    private ActivityResultLauncher<String[]> resourcePackPicker;
    private ActivityResultLauncher<Uri> worldFolderPicker;
    private ActivityResultLauncher<String[]> runtimePicker;
    private TextView modStatus;
    private TextView resourceStatus;
    private TextView worldStatus;
    private TextView runtimeStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        SharedPreferences prefs = getSharedPreferences("voidlaunch", MODE_PRIVATE);
        TextView user = findViewById(R.id.tv_username);
        user.setText(prefs.getString("username", "Player") + " · LOCAL PROFILE");
        TextView modeStatus = findViewById(R.id.tv_mode_status);
        Button modeButton = findViewById(R.id.btn_toggle_mode);
        Runnable refreshMode = () -> {
            boolean offline = prefs.getBoolean("offline_mode", true);
            modeStatus.setText(offline ? "MODE · OFFLINE (LOCAL FEATURES ONLY)" : "MODE · ONLINE (NETWORK AVAILABLE)");
            modeStatus.setTextColor(offline ? 0xff86efac : 0xff93c5fd);
            modeButton.setText(offline ? "SWITCH TO ONLINE MODE" : "SWITCH TO OFFLINE MODE");
        };
        refreshMode.run();
        modeButton.setOnClickListener(v -> {
            boolean nowOffline = !prefs.getBoolean("offline_mode", true);
            prefs.edit().putBoolean("offline_mode", nowOffline).apply();
            refreshMode.run();
            Toast.makeText(this, nowOffline ? "Offline profile enabled. Game engine is still required." : "Online profile enabled. Sign-in and engine services are still required.", Toast.LENGTH_LONG).show();
        });
        findViewById(R.id.btn_permissions).setOnClickListener(v -> showPermissionManager());
        findViewById(R.id.btn_engine_check).setOnClickListener(v ->
                new androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("VØID · Horizon compatibility")
                        .setMessage(EngineCompatibility.report(this))
                        .setPositiveButton("OK", null)
                        .show());

        Spinner quality = findViewById(R.id.spinner_version);
        quality.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, QUALITY));
        quality.setSelection(prefs.getInt("quality", 0));
        quality.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, android.view.View v, int pos, long id) {
                prefs.edit().putInt("quality", pos).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) { }
        });

        SeekBar ram = findViewById(R.id.seekbar_ram);
        TextView ramLabel = findViewById(R.id.tv_ram);
        ram.setMax(3); // profile preference only; engine must enforce safe device limits
        ram.setProgress(prefs.getInt("ram_profile", 1));
        updateRamLabel(ramLabel, ram.getProgress());
        ram.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int value, boolean fromUser) {
                updateRamLabel(ramLabel, value);
                prefs.edit().putInt("ram_profile", value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });

        modStatus = findViewById(R.id.tv_mod_status);
        resourceStatus = findViewById(R.id.tv_resource_status);
        worldStatus = findViewById(R.id.tv_world_status);
        runtimeStatus = findViewById(R.id.tv_runtime_status);
        modPicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onModPicked);
        resourcePackPicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onResourcePackPicked);
        worldFolderPicker = registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), this::onWorldFolderPicked);
        runtimePicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), this::onRuntimePicked);
        findViewById(R.id.btn_mods).setOnClickListener(v -> modPicker.launch(new String[]{"application/octet-stream", "application/zip", "*/*"}));
        findViewById(R.id.btn_resource_packs).setOnClickListener(v -> resourcePackPicker.launch(new String[]{"application/zip", "application/octet-stream"}));
        findViewById(R.id.btn_world_folder).setOnClickListener(v -> worldFolderPicker.launch(null));
        findViewById(R.id.btn_runtime).setOnClickListener(v -> runtimePicker.launch(new String[]{"application/zip", "application/octet-stream", "*/*"}));
        findViewById(R.id.btn_join).setOnClickListener(v -> showEnginePending("Instant Join"));
        findViewById(R.id.btn_create).setOnClickListener(v -> showEnginePending("Instant Create World"));
        findViewById(R.id.btn_launch).setOnClickListener(v -> showEnginePending("Play"));
        findViewById(R.id.btn_logout).setOnClickListener(v -> {
            prefs.edit().clear().apply();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
        refreshMods();
        refreshLibraryStatuses();
    }

    private void showPermissionManager() {
        String notificationState;
        if (Build.VERSION.SDK_INT < 33) {
            notificationState = "Notifications: controlled by Android settings on this version.";
        } else {
            boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            notificationState = "Notifications: " + (granted ? "allowed" : "not allowed (optional)");
        }
        String message = "VØID requests access only when a feature needs it.\n\n"
                + "• Internet / network: declared for future online services; no runtime prompt.\n"
                + "• Game files, worlds, mods and resource packs: use Android's file picker; grant access only to files you choose.\n"
                + "• Camera and microphone: not requested because the current build has no feature that needs them.\n\n"
                + notificationState;
        androidx.appcompat.app.AlertDialog.Builder dialog = new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("VØID Permission Manager")
                .setMessage(message)
                .setNegativeButton("Close", null);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            dialog.setPositiveButton("Allow notifications", (d, which) -> ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 410));
        }
        dialog.show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 410) {
            Toast.makeText(this, grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                    ? "Notifications permission granted." : "Notifications remain disabled. VØID can still be used.", Toast.LENGTH_LONG).show();
        }
    }

    private void updateRamLabel(TextView label, int progress) {
        String[] labels = {"Conservative", "Balanced", "Performance", "Maximum (device permitting)"};
        label.setText("Memory profile: " + labels[progress]);
    }

    private void showEnginePending(String feature) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(feature + " unavailable")
                .setMessage("The VØID launcher shell is ready, but the Horizon game engine is not integrated in this build. No game will start from this button yet. See docs/ENGINE_ADOPTION.md for the verified integration plan.")
                .setPositiveButton("OK", null).show();
    }

    private void onModPicked(Uri uri) {
        if (uri == null) return;
        String name = DocumentFile.fromSingleUri(this, uri) != null
                ? DocumentFile.fromSingleUri(this, uri).getName() : "selected file";
        if (name == null) name = "selected file";
        if (!name.toLowerCase().endsWith(".hmod") && !name.toLowerCase().endsWith(".zip")) {
            Toast.makeText(this, "Choose a Horizon .hmod or a resource-pack .zip file. Java .jar mods are not supported by this engine.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) {
            // Some document providers grant only temporary access.
        }
        SharedPreferences p = getSharedPreferences("voidlaunch", MODE_PRIVATE);
        List<String> entries = new ArrayList<>(p.getStringSet("mod_uris", new java.util.HashSet<>()));
        entries.add(uri.toString() + "|" + name);
        p.edit().putStringSet("mod_uris", new java.util.HashSet<>(entries)).apply();
        refreshMods();
        Toast.makeText(this, "Added to import list. Engine compatibility is not verified.", Toast.LENGTH_LONG).show();
    }

    private void onResourcePackPicked(Uri uri) {
        if (uri == null) return;
        String name = displayName(uri);
        if (!name.toLowerCase(java.util.Locale.ROOT).endsWith(".zip")) {
            Toast.makeText(this, "Choose a .zip resource pack.", Toast.LENGTH_LONG).show();
            return;
        }
        persistReadPermission(uri);
        addUriToSet("resource_pack_uris", uri.toString() + "|" + name);
        refreshLibraryStatuses();
        Toast.makeText(this, "Resource pack reference saved. Engine loading is not available yet.", Toast.LENGTH_LONG).show();
    }

    private void onWorldFolderPicked(Uri uri) {
        if (uri == null) return;
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }
        catch (SecurityException ignored) { }
        getSharedPreferences("voidlaunch", MODE_PRIVATE).edit().putString("world_tree_uri", uri.toString()).apply();
        refreshLibraryStatuses();
        Toast.makeText(this, "World folder access saved. World creation/loading needs the game engine.", Toast.LENGTH_LONG).show();
    }

    private void onRuntimePicked(Uri uri) {
        if (uri == null) return;
        String name = displayName(uri);
        persistReadPermission(uri);
        getSharedPreferences("voidlaunch", MODE_PRIVATE).edit().putString("runtime_package_uri", uri.toString()).putString("runtime_package_name", name).apply();
        refreshLibraryStatuses();
        Toast.makeText(this, "Runtime package reference saved only. It is not installed or executable in this alpha.", Toast.LENGTH_LONG).show();
    }

    private String displayName(Uri uri) {
        DocumentFile file = DocumentFile.fromSingleUri(this, uri);
        String name = file != null ? file.getName() : null;
        return name == null ? "selected file" : name;
    }

    private void persistReadPermission(Uri uri) {
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (SecurityException ignored) { }
    }

    private void addUriToSet(String key, String value) {
        SharedPreferences prefs = getSharedPreferences("voidlaunch", MODE_PRIVATE);
        java.util.Set<String> current = new java.util.HashSet<>(prefs.getStringSet(key, new java.util.HashSet<>()));
        current.add(value);
        prefs.edit().putStringSet(key, current).apply();
    }

    private void refreshMods() {
        java.util.Set<String> mods = getSharedPreferences("voidlaunch", MODE_PRIVATE).getStringSet("mod_uris", new java.util.HashSet<>());
        modStatus.setText("Import list: " + mods.size() + " file(s) · not yet loaded by engine");
    }

    private void refreshLibraryStatuses() {
        SharedPreferences prefs = getSharedPreferences("voidlaunch", MODE_PRIVATE);
        java.util.Set<String> packs = prefs.getStringSet("resource_pack_uris", new java.util.HashSet<>());
        resourceStatus.setText("Resource packs selected: " + packs.size() + " · not yet loaded by engine");
        String tree = prefs.getString("world_tree_uri", null);
        worldStatus.setText(tree == null ? "World folder: not selected" : "World folder: access saved (engine required)");
        String runtime = prefs.getString("runtime_package_name", null);
        runtimeStatus.setText(runtime == null ? "Runtime: not selected · engine adapter required" : "Selected: " + runtime + " · not installed or executed");
    }
}
