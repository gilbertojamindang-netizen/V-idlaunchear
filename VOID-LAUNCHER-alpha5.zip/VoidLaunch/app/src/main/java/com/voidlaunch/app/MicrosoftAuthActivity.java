package com.voidlaunch.app;

import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Microsoft/Xbox sign-in is intentionally disabled until a valid app registration,
 * redirect URI and secure token exchange are configured. Never store an auth code as a token. */
public class MicrosoftAuthActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(this,
                "Microsoft sign-in is not configured yet. Use Offline Mode for the preview.",
                Toast.LENGTH_LONG).show();
        finish();
    }
}
