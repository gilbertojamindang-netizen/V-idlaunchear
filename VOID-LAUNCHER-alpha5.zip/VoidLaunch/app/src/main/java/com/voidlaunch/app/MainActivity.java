package com.voidlaunch.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button microsoft = findViewById(R.id.btn_microsoft);
        Button offline = findViewById(R.id.btn_offline);
        microsoft.setOnClickListener(v -> startActivity(new Intent(this, MicrosoftAuthActivity.class)));
        offline.setOnClickListener(v -> startActivity(new Intent(this, OfflineLoginActivity.class)));
    }
}
