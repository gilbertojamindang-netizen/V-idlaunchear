# VØID LAUNCHER — 0.5.0-alpha

An Android launcher-shell prototype being prepared for a Horizon Android engine adoption. **This ZIP is not a playable Minecraft build.** It contains no game engine, Minecraft assets, worlds, account tokens, or APK.

## What is in this alpha

- Android Java launcher shell and dark VØID UI.
- Local offline-name profile (this is not Minecraft offline gameplay by itself).
- Android device preflight for API level, ARM64 ABI and Vulkan feature reporting.
- Permission screen; selected files and folders use Android Storage Access Framework.
- Add-on and resource-pack file selection (references only; not installed into a game).
- Worlds-folder and runtime-package selection (references only).
- Low-end profile preferences (not yet applied to a renderer).
- Play / Instant Join / Create World actions clearly report that the engine is not integrated.
- Gradle 8.7 / Android Gradle Plugin 8.6.1 build configuration and GitHub Actions workflow.

## Engine decision

The chosen route is to adopt the native Rust-based Horizon Android project as the game engine, rather than trying to embed it as if it were a Java library. See [`docs/ENGINE_ADOPTION.md`](docs/ENGINE_ADOPTION.md). The selected upstream currently targets Minecraft Java 26.3 on ARM64 Android with Vulkan; it is not a general-purpose launcher for arbitrary Java versions. Its Android documentation describes singleplayer and Java multiplayer, and says installed resources can be reused offline after the initial download.

Horizon does not run Fabric, Forge or NeoForge Java `.jar` mods. Its Android port uses its own native `.hmod` mod format and resource-pack support. A Java Runtime Manager is not part of the Horizon game runtime path.

## Build the current VØID shell

- Android Studio or AndroidIDE
- JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- Gradle 8.7

Open this folder as a Gradle project and sync, then run `assembleDebug`. The repository has Gradle wrapper properties but intentionally does not include the wrapper JAR/scripts; the included GitHub Actions workflow installs Gradle 8.7 directly.

## Current limitations

| Feature | Current status |
|---|---|
| Launcher UI / local profile | Implemented |
| Device compatibility preflight | Diagnostic only |
| File and folder pickers | Implemented; references only |
| Actual Horizon engine | Not integrated |
| Offline Minecraft gameplay | Not available in this shell |
| World create/load/save | Requires engine |
| Vulkan rendering | Requires engine; preflight is not a GPU test |
| Instant Join / multiplayer | Requires engine and server/account support |
| Microsoft authentication | Not configured |
| `.hmod` install / resource-pack loading | Requires engine adapter |
| Fabric / Forge / NeoForge JAR mods | Not supported by the Horizon route |

## Legal and security notes

VØID is unofficial and is not affiliated with Mojang or Microsoft. Horizon is also unofficial. Do not commit Minecraft game files, proprietary assets, user credentials, refresh tokens, signing keys, or generated game caches. Users must provide a legitimate Minecraft Java Edition entitlement where required. Preserve the upstream license and third-party notices when integrating engine source.
